import state from '../state'

const loginLocal = (_, { userId, firstName, lastName, currentRole, timeZone, roles, remainingCharge }, { cache }) => {
  cache.writeData({
    data: {
      me: {
        __typename: 'Me',
        userId,
        firstName,
        lastName,
        // timeZone,
        currentRole: currentRole.toLowerCase(),
        remainingCharge,
      },
      roles: {
        __typename: 'Role',
        json: roles.map(role => role.toLowerCase()),
      },
    },
  })

  return null
}

const logoutLocal = (_, args, { cache }) => {
  cache.writeData({
    data: {
      ...state,
    },
  })

  return null
}

export { loginLocal, logoutLocal }
