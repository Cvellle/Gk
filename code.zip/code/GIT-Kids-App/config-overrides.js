const rewireAliases = require('react-app-rewire-aliases')
const { paths } = require('react-app-rewired')
const path = require('path')

/* config-overrides.js */
module.exports = override = (config, env) => {
    config = rewireAliases.aliasesOptions({
        '@apollo': path.resolve(__dirname, `${paths.appSrc}/apollo/`),
        '@assets': path.resolve(__dirname, `${paths.appSrc}/assets/`),
        '@components': path.resolve(__dirname, `${paths.appSrc}/components/`),
        '@constants': path.resolve(__dirname, `${paths.appSrc}/constants/`),
        '@forms': path.resolve(__dirname, `${paths.appSrc}/forms/`),
        '@inputs': path.resolve(__dirname, `${paths.appSrc}/inputs/`),
        '@layouts': path.resolve(__dirname, `${paths.appSrc}/layouts/`),
        '@pages': path.resolve(__dirname, `${paths.appSrc}/pages/`),
        '@router': path.resolve(__dirname, `${paths.appSrc}/router/`),
        '@util': path.resolve(__dirname, `${paths.appSrc}/util/`),
    })(config, env)
    return config
}
