import React from 'react'
import PropTypes from 'prop-types'
import { FastField, Field, getIn } from 'formik'
import InputBase from '@material-ui/core/InputBase'

export const getErrorFromField = formik => {
  const { field, form } = formik
  if (!field || !form || Object.keys(field).length === 0 || Object.keys(form).length === 0) {
    throw new Error(
      // eslint-disable-next-line max-len
      "field & form is required, make sure that it is passed from Formik's Field",
    )
  }
  // use getIn to support name in lodash-like dot paths
  // ex. field.name = 'social.twitter'
  if (!field.name) {
    throw new Error(
      // eslint-disable-next-line max-len
      "field should have a name, did you forget to pass 'name' to Field?",
    )
  }
  const errorText = getIn(form.errors, field.name) || ''
  const errorShown = (getIn(form.touched, field.name) || false) && Boolean(errorText)
  return [errorShown, errorText]
}

const Component = ({ field, form, renderHelperText, ...props }) => {
  const [errorShown, errorText] = getErrorFromField({ field, form })
  return (
    <>
      <InputBase error={errorShown} {...props} {...field} />
      {renderHelperText(errorShown, errorText)}
    </>
  )
}

const InputBaseField = ({ fastFieldUsed, ...props }) => {
  const similarProps = { ...props, component: Component }
  return fastFieldUsed ? <FastField {...similarProps} /> : <Field {...similarProps} />
}

InputBaseField.propTypes = {
  renderHelperText: PropTypes.func,
}
InputBaseField.defaultProps = {
  renderHelperText: () => null,
}

export default InputBaseField
