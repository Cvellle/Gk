import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'
import Select from '@material-ui/core/Select'
import MenuItem from '@material-ui/core/MenuItem'
import Cancel from '@material-ui/icons/Cancel'
import Save from '@material-ui/icons/Save'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Button from '@components/CustomButtons/Button'
import Input from '@components/CustomInput/CustomInput'
import styles from '@assets/jss/forms/editEducationalProgramForm'

const useStyles = makeStyles(styles)

const EditCourseForm = ({ courseProgram, history }) => {
  const c = useStyles()

  return (
    <>
      <GridContainer>
        <GridItem xs={12} sm={6} md={6} lg={6}>
          <Input
            inputProps={{
              value: courseProgram.name,
            }}
            formControlProps={{ fullWidth: true }}
            labelText="Name"
          />
          <Input
            inputProps={{
              value: courseProgram.description,
              multiline: true,
            }}
            formControlProps={{ fullWidth: true }}
            labelText="Description"
          />
          <Input
            inputProps={{
              value: courseProgram.publisher,
            }}
            formControlProps={{ fullWidth: true }}
            labelText="Publisher"
          />
          <Input
            inputProps={{
              value: courseProgram.price,
            }}
            formControlProps={{ fullWidth: true }}
            labelText="Price"
          />
          <FormControl fullWidth className={c.selectFormControl}>
            <InputLabel htmlFor="simple-select" className={c.selectLabel}>
              Choose Level
            </InputLabel>
            <Select
              MenuProps={{
                className: c.selectMenu,
              }}
              classes={{
                select: c.select,
              }}
              value={''}
              //	onChange={this.handleSimple}
              inputProps={{
                name: 'levelSelect',
                id: 'levelSelect',
              }}
            >
              <MenuItem
                disabled
                classes={{
                  root: c.selectMenuItem,
                }}
              >
                Choose Level
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="A1"
              >
                A1
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="A2"
              >
                A2
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="B1"
              >
                B1
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="B2"
              >
                B2
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="C1"
              >
                C1
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="C2"
              >
                C2
              </MenuItem>
            </Select>
          </FormControl>
          <FormControl fullWidth className={c.selectFormControl}>
            <InputLabel htmlFor="simple-select" className={c.selectLabel}>
              Choose Group
            </InputLabel>
            <Select
              MenuProps={{
                className: c.selectMenu,
              }}
              classes={{
                select: c.select,
              }}
              value={''}
              //	onChange={this.handleSimple}
              inputProps={{
                name: 'groupSelect',
                id: 'groupSelect',
              }}
            >
              <MenuItem
                disabled
                classes={{
                  root: c.selectMenuItem,
                }}
              >
                Choose Group
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="kids"
              >
                Kids
              </MenuItem>
              <MenuItem
                classes={{
                  root: c.selectMenuItem,
                  selected: c.selectMenuItemSelected,
                }}
                value="adults"
              >
                Adults
              </MenuItem>
            </Select>
          </FormControl>
        </GridItem>
        <GridItem xs={12} sm={6} md={6} lg={6}>
          <div>sekcije</div>
        </GridItem>
      </GridContainer>
      <GridContainer justify="flex-end" style={{ padding: 15 }}>
        <Button className={c.button} onClick={() => history.goBack()}>
          Cancel <Cancel className={c.icon} />
        </Button>
        <Button className={c.button} color="primary">
          Save <Save className={c.icon} />
        </Button>
      </GridContainer>
    </>
  )
}

export default EditCourseForm
