import React, { useState } from 'react'
import { withStyles } from '@material-ui/core'

import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Button from '@components/CustomButtons/Button'
import { FormikTextInput, FormikDatePicker } from '@inputs'
import Card from '@components/Card/Card'
import { Formik, Field } from 'formik'
import * as Yup from 'yup'
import { UPDATE_PROFILE } from '@apollo/server/mutations/user'
import { USERS_QUERY } from '@apollo/server/queries'

import useReactRouter from 'use-react-router'

import style from '@assets/jss/forms/addUserForm'

import { useMutation, useQuery } from 'react-apollo-hooks'

import { makeStyles } from '@material-ui/core/styles'

const validationSchema = Yup.object().shape({
    oldPassword:Yup.string().required('Lozinka je obavezna!'),
    newPassword: Yup.string().min(6, 'Lozinka mora sadržati bar 6 karaktera!'),
    firstName: Yup.string().required('Ime je obavezno!'),
    lastName: Yup.string().required('Prezime je obavezno!'),
    city: Yup.string().required('Grad je obavezan!'),
    phone: Yup.string().required('Telefon je obavezan!'),
    birthDate: Yup.string().required('Datum rođenja je obavezan!'),
    postalCode: Yup.string().required('Poštanski kod je obavezan!')
})

const initialValues = {
    oldPassword: '',
    newPassword: '',
    firstName: '',
    lastName: '',
    city: '',
    phone: '',
    birthDate: '',
    postalCode: '',
}

const useStyles = makeStyles({
    root: {
      '& .MuiFormHelperText-root': {
        display: 'none',
      },
    },
  })

const UpdateProfileForm = ({ classes: c }) => {

    const classesField = useStyles()

    const { data } = useQuery(USERS_QUERY, {
        variables: { id: window.localStorage["currentUserId"] },
    })

    if (data && data.users && data.users.docs[0]) {
        console.log(data.users.docs[0])
        initialValues.firstName = data.users.docs[0].firstName
        initialValues.lastName = data.users.docs[0].lastName
        initialValues.city = data.users.docs[0].city
        initialValues.phone = data.users.docs[0].phone
        initialValues.birthDate = data.users.docs[0].birthDate.toString()
        initialValues.postalCode = data.users.docs[0].postalCode
    }

    const { history } = useReactRouter()
    const [hasErrors,setErrorState] = useState({isTrue: false, message: null})
    const [successMsg, setSuccessStatus] = useState(false)
    const updateProfileMutation = useMutation(UPDATE_PROFILE)
    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={async (values, actions) => {
                try {
                     await updateProfileMutation({
                        variables: values,
                        refetchQueries: [
                            { query: USERS_QUERY, variables: { id: window.localStorage["currentUserId"] } },
                        ],
                    })
                    actions.setSubmitting(false)
                    setSuccessStatus(true)
                    setErrorState({isTrue: false, message: null})
                    setTimeout(() => history.push('/'), 1500)
                } catch ({graphQLErrors}) {
                    setSuccessStatus(false)
                    actions.setSubmitting(false)
                    setErrorState({isTrue: true, message: graphQLErrors.toString().slice(6)})
                }
            }}
            render={({ handleSubmit, isSubmitting }) => (
                <Card className={c.card}>
                    <form onSubmit={handleSubmit} noValidate>
                        <div className={c.formHeader}>
                            <h3 className={c.title}>{`Izmeni Profil`}</h3>
                        </div>
                        <div className={c.content}>
                            <GridContainer justify="flex-start">
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        type="password"
                                        placeholder="Unesi staru lozinku."
                                        name="oldPassword"
                                        label="Stara Lozinka"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                        classes={{
                                            root: classesField.root,
                                          }}
                                    />
                                    <div style={{ height: '14px' }}>
                                  </div>
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        name="newPassword"
                                        type="password"
                                        label="Nova Lozinka"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="firstName"
                                        label="Ime"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="lastName"
                                        label="Prezime"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="postalCode"
                                        label="Poštanski broj"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>

                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="city"
                                        label="Grad"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="phone"
                                        label="Telefon"
                                        component={FormikTextInput}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="birthDate"
                                        label="Datum rođenja"
                                        component={FormikDatePicker}
                                        onFocus={()=>setErrorState({isTrue: false, message: null})}
                                    />
                                </GridItem>
                            </GridContainer>
                        </div>
                        <div className={c.footer}>
                            <GridContainer justify="flex-end">
                                <Button
                                    className={c.button}
                                    color="primary"
                                    type="submit"
                                    disabled={isSubmitting}
                                >
                                    Potvrdi
                                </Button>
                            </GridContainer>
                        </div>
                        {<p style={{color:'red',visibility:'visible', height:'15px', textAlign:'center'}}>{hasErrors.isTrue ? hasErrors.message :' '}</p>}
                        {<p style={{ transform:'scale(1.2)', color: 'limegreen', visibility: 'visible', height: '15px', textAlign: 'center' }}>{successMsg ? 'Usepešno ste izmenili podatke' : ' '}</p>}
                    </form>
                </Card>
            )}
        />
    )
}

export default withStyles(style)(UpdateProfileForm)
