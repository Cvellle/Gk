import EditProfileForm from './EditProfileForm'

export default EditProfileForm
