import gql from 'graphql-tag'

const LOGIN_LOCAL = gql`
  mutation(
    $userId: String
    $firstName: String!
    $lastName: String!
    $currentRole: String!
    # $timeZone: String!
    $roles: [Role!]!
  ) {
    loginLocal(
      userId: $userId
      firstName: $firstName
      lastName: $lastName
      currentRole: $currentRole
      # timeZone: $timeZone
      roles: $roles
    ) @client
  }
`

const LOGOUT_LOCAL_MUTATION = gql`
  mutation {
    logoutLocal @client
  }
`

export { LOGIN_LOCAL, LOGOUT_LOCAL_MUTATION }
