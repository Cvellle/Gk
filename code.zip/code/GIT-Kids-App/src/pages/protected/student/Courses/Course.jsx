import React, { useState } from 'react'
import useReactRouter from 'use-react-router'
import { makeStyles } from '@material-ui/core/styles'
import { List, ListItemText, ListItem } from '@material-ui/core'
import Container from '@material-ui/core/Container'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Button from '@components/CustomButtons/Button'
import Accordion from '@components/Accordion'
import Player from '@components/Player'
import coursePoster1 from '@assets/images/courses/card-1.jpeg'
import coursePoster2 from '@assets/images/courses/card-2.jpeg'
import coursePoster3 from '@assets/images/courses/card-3.jpeg'
import coursePoster4 from '@assets/images/courses/card-1.jpeg'
// import imagePlaceholder from '@assets/images/placeholder.jpg'
import styles from '@assets/jss/pages/singleCourse'

const useStyles = makeStyles(styles)

const fakeProgram = [
  {
    id: 1,
    courseSlug: `prvi-kurs`,
    image: coursePoster1,
    name: 'A1 Prvi kurs',
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A1',
    status: 'draft',
    lectures: [
      {
        name: 'Lekcija 1',
        slug: `lekcija-1`,
        videoHash: `vj83tc4hmj`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 2',
        slug: `lekcija-2`,
        videoHash: `s7vgegzd49`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 3',
        slug: `lekcija-3`,
        videoHash: `zizzhg0u9i`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
    ],
  },
  {
    id: 2,
    courseSlug: `drugi-kurs`,
    image: coursePoster2,
    name: 'A2 Drugi kurs',
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A2',
    status: 'draft',
    lectures: [
      {
        name: 'Lekcija 1',
        slug: `lekcija-1`,
        videoHash: `vj83tc4hmj`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 2',
        slug: `lekcija-2`,
        videoHash: `s7vgegzd49`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 3',
        slug: `lekcija-3`,
        videoHash: `zizzhg0u9i`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
    ],
  },
  {
    id: 3,
    courseSlug: `treci-kurs`,
    image: coursePoster3,
    name: 'A3 Treci kurs',
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A3',
    status: 'draft',
    lectures: [
      {
        name: 'Lekcija 1',
        slug: `lekcija-1`,
        videoHash: `vj83tc4hmj`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 2',
        slug: `lekcija-2`,
        videoHash: `s7vgegzd49`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 3',
        slug: `lekcija-3`,
        videoHash: `zizzhg0u9i`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
    ],
  },
  {
    id: 4,
    courseSlug: `cetvrti-kurs`,
    image: coursePoster4,
    name: 'A4 Cetvrti kurs',
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A4',
    status: 'draft',
    lectures: [
      {
        name: 'Lekcija 1',
        slug: `lekcija-1`,
        videoHash: `vj83tc4hmj`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 2',
        slug: `lekcija-2`,
        videoHash: `s7vgegzd49`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
      {
        name: 'Lekcija 3',
        slug: `lekcija-3`,
        videoHash: `zizzhg0u9i`,
        description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
      },
    ],
  },
]

const sekcije = [
  { sekcija: `SEKCIJA #1` },
  { sekcija: `SEKCIJA #2` },
  { sekcija: `SEKCIJA #3` },
  { sekcija: `SEKCIJA #4` },
]

const CoursePage = () => {
  const c = useStyles()

  const [currLesson, setCurrLesson] = useState(0)

  const onClickLesson = index => setCurrLesson(index)

  const { history, location, match } = useReactRouter()

  const program = fakeProgram.find(el => el.courseSlug === match.params.courseName)

  const videoSRC = program.lectures[currLesson].videoHash
  const Video = () => <Player videoHash={videoSRC} />

  // console.log('path', location)
  // console.log('match', match)
  // console.log('videoSRC', videoSRC)
  // console.log('currLesson', currLesson)

  return (
    <>
      {/* <Container maxWidth="md"> */}
      <Container>
        <h2 className={c.title}>{program.name}</h2>
        <div className={c.textBox}></div>
        <GridContainer justify="space-evenly" alignItems="flex-start">
          <GridItem xs={12} sm={7} md={6} lg={6} className={c.infoContainer}>
            {/* <Player videoHash={videoSRC} /> */}
            <div
              style={{
                paddingBottom: '1rem',
              }}
            >
              <Video />
            </div>
            {/* <img src={program.image} alt="Minakwa Learning Platform" /> */}
            <div>
              <GridContainer>
                <p className={c.boldText}>Publisher:&nbsp;</p>
                <p>{program.publisher}</p>
              </GridContainer>
              <GridContainer>
                <p className={c.boldText}>Group:&nbsp;</p>
                <p> {program.targetGroup}</p>
              </GridContainer>
              <GridContainer>
                <p className={c.boldText}>Level:&nbsp;</p>
                <p>{program.level}</p>
              </GridContainer>
            </div>
            <div className={c.textBox}>
              <p className={c.descriptionText}>{program.description}</p>
            </div>
            <Button color="primary" size="sm" onClick={() => history.push('/my-courses')}>
              Back
            </Button>
          </GridItem>
          <GridItem xs={12} sm={5} md={5} lg={5}>
            <List>
              {/* <p>Lista sekcija:</p> */}
              {sekcije.map(el => (
                <Accordion
                  key={el.sekcija}
                  active={0}
                  collapses={[
                    {
                      title: el.sekcija,
                    },
                  ]}
                >
                  {program.lectures.map((lecture, index) => (
                    <ListItem key={index} className={c.listItem} onClick={() => onClickLesson(index)}>
                      <ListItemText>{lecture.name}</ListItemText>
                    </ListItem>
                  ))}
                </Accordion>
              ))}
            </List>
          </GridItem>
        </GridContainer>
      </Container>
    </>
  )
}

export default CoursePage
