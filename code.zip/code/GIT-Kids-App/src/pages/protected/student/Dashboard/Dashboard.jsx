import React from 'react'
import MyCourses from '../Courses/MyCourses'

const DashboardPage = () => <MyCourses />

export default DashboardPage
