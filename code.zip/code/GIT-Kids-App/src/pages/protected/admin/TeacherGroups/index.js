import TeacherGroups from './TeacherGroups'

export default TeacherGroups
