import MyProfile from '../../default/MyProfile/MyProfile'

export default MyProfile
