import React from 'react'
import List from '@material-ui/core/List'
import Accordion from '@components/Accordion'
import SectionItem from './SectionItem'

const SectionBar = ({ program }) => (
  <List>
    {program.sections.map((el, i) => (
      <Accordion
        key={el.section}
        activeProp={i === 0 ? 0 : -1}
        collapses={[
          {
            title: el.section,
          },
        ]}
      >
        {el.lectures.map((lecture, index) => (
          <SectionItem key={index} lectureName={lecture.name} lectureSlug={lecture.slug} />
        ))}
      </Accordion>
    ))}
  </List>
)

export default SectionBar
