import React from 'react'
import { useParams } from 'react-router-dom'
import { makeStyles } from '@material-ui/core/styles'
import Container from '@material-ui/core/Container'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Button from '@components/CustomButtons/Button'
import VideoLesson from './VideoLesson'
import SectionBar from './SectionsBar'
import styles from '@assets/jss/pages/singleCourse'

import fakeProgram from '../fakeProgram'

const useStyles = makeStyles(styles)

const CoursePage = ({ history }) => {
  const c = useStyles()

  const { courseName } = useParams()

  const program = fakeProgram.find(el => el.courseSlug === courseName)
  const lessons = program.sections.flatMap(section => section.lectures)
  const Video = () => (lessons ? <VideoLesson lessons={lessons} /> : <div>loading...</div>)

  const onBack = () => history.push('/courses')
  const onEdit = () => history.push(`/courses/${courseName}/edit`)

  return (
    <>
      {/* <Container maxWidth="md"> */}
      <Container>
        <h2 className={c.title}>{program.name}</h2>
        <div className={c.textBox}></div>
        <GridContainer justify="space-evenly" alignItems="flex-start">
          <GridItem xs={12} sm={7} md={6} lg={6} className={c.infoContainer}>
            <div
              style={{
                paddingBottom: '1rem',
              }}
            >
              <Video />
            </div>
            <div>
              <GridContainer>
                <p className={c.boldText}>Publisher:&nbsp;</p>
                <p>{program.publisher}</p>
              </GridContainer>
              <GridContainer>
                <p className={c.boldText}>Group:&nbsp;</p>
                <p> {program.targetGroup}</p>
              </GridContainer>
              <GridContainer>
                <p className={c.boldText}>Level:&nbsp;</p>
                <p>{program.level}</p>
              </GridContainer>
            </div>
            <div className={c.textBox}>
              <p className={c.descriptionText}>{program.description}</p>
            </div>
            <Button color="primary" size="sm" onClick={onBack}>
              Back
            </Button>
            <Button color="danger" size="sm" onClick={onEdit}>
              Edit
            </Button>
          </GridItem>
          <GridItem xs={12} sm={5} md={5} lg={5}>
            <SectionBar program={program} />
          </GridItem>
        </GridContainer>
      </Container>
    </>
  )
}

export default CoursePage
