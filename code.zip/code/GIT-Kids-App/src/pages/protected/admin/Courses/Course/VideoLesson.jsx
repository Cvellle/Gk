import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import Player from '@components/Player'

const VideoLesson = ({ lessons }) => {
  const { lesson } = useParams()
  const [lection, setLection] = useState(lesson)

  useEffect(() => {
    if (lessons) {
      const data = lessons.find(el => el.slug === lesson)
      setLection(data)
    }
  }, [lesson, lessons])

  return <Player videoHash={lection.videoHash} />
}

export default VideoLesson
