import coursePoster1 from '@assets/images/courses/card-1.jpeg'
import coursePoster2 from '@assets/images/courses/card-2.jpeg'
import coursePoster3 from '@assets/images/courses/card-3.jpeg'
import coursePoster4 from '@assets/images/courses/card-1.jpeg'

export default [
  {
    id: 1,
    courseSlug: `prvi-kurs`,
    image: coursePoster1,
    name: 'A1 Prvi kurs',
    shortDesc: `Opis za prvi kurs`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A1',
    status: 'draft',
    sections: [
      {
        section: `SEKCIJA #1`,
        lectures: [
          {
            name: 'Lekcija 1',
            slug: `lekcija-1`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 2',
            slug: `lekcija-2`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 3',
            slug: `lekcija-3`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #2`,
        lectures: [
          {
            name: 'Lekcija 4',
            slug: `lekcija-4`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 5',
            slug: `lekcija-5`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 6',
            slug: `lekcija-6`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #3`,
        lectures: [
          {
            name: 'Lekcija 7',
            slug: `lekcija-7`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 8',
            slug: `lekcija-8`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 9',
            slug: `lekcija-9`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
    ],
  },
  {
    id: 2,
    courseSlug: `drugi-kurs`,
    image: coursePoster2,
    name: 'A2 Drugi kurs',
    shortDesc: `Opis za drugi kurs`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A2',
    status: 'draft',
    sections: [
      {
        section: `SEKCIJA #1`,
        lectures: [
          {
            name: 'Lekcija 1',
            slug: `lekcija-1`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 2',
            slug: `lekcija-2`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 3',
            slug: `lekcija-3`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #2`,
        lectures: [
          {
            name: 'Lekcija 4',
            slug: `lekcija-4`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 5',
            slug: `lekcija-5`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 6',
            slug: `lekcija-6`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #3`,
        lectures: [
          {
            name: 'Lekcija 7',
            slug: `lekcija-7`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 8',
            slug: `lekcija-8`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 9',
            slug: `lekcija-9`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
    ],
  },
  {
    id: 3,
    courseSlug: `treci-kurs`,
    image: coursePoster3,
    name: 'A3 Treci kurs',
    shortDesc: `Opis za treci kurs`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A3',
    status: 'draft',
    sections: [
      {
        section: `SEKCIJA #1`,
        lectures: [
          {
            name: 'Lekcija 1',
            slug: `lekcija-1`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 2',
            slug: `lekcija-2`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 3',
            slug: `lekcija-3`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #2`,
        lectures: [
          {
            name: 'Lekcija 4',
            slug: `lekcija-4`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 5',
            slug: `lekcija-5`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 6',
            slug: `lekcija-6`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #3`,
        lectures: [
          {
            name: 'Lekcija 7',
            slug: `lekcija-7`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 8',
            slug: `lekcija-8`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 9',
            slug: `lekcija-9`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
    ],
  },
  {
    id: 4,
    courseSlug: `cetvrti-kurs`,
    image: coursePoster4,
    name: 'A4 Cetvrti kurs',
    shortDesc: `Opis za cetvrti kurs`,
    description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
    price: 22,
    publisher: 'GOLUX',
    targetGroup: 'Kids',
    level: 'A4',
    status: 'draft',
    sections: [
      {
        section: `SEKCIJA #1`,
        lectures: [
          {
            name: 'Lekcija 1',
            slug: `lekcija-1`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 2',
            slug: `lekcija-2`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 3',
            slug: `lekcija-3`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #2`,
        lectures: [
          {
            name: 'Lekcija 4',
            slug: `lekcija-4`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 5',
            slug: `lekcija-5`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 6',
            slug: `lekcija-6`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
      {
        section: `SEKCIJA #3`,
        lectures: [
          {
            name: 'Lekcija 7',
            slug: `lekcija-7`,
            videoHash: `vj83tc4hmj`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 8',
            slug: `lekcija-8`,
            videoHash: `s7vgegzd49`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
          {
            name: 'Lekcija 9',
            slug: `lekcija-9`,
            videoHash: `zizzhg0u9i`,
            description: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy`,
          },
        ],
      },
    ],
  },
]
