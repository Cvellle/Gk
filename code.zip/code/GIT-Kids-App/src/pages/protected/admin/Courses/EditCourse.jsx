import React from 'react'
import { useParams } from 'react-router-dom'
import EditForm from '@forms/EditCourse'

import fakeProgram from './fakeProgram'

const EditCoursePage = ({ history }) => {
  const { courseName } = useParams()

  const program = fakeProgram.find(el => el.courseSlug === courseName)

  return <EditForm history={history} courseProgram={program} />
}
export default EditCoursePage
