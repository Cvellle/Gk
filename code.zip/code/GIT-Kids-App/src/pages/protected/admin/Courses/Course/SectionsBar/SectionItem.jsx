import React from 'react'
import { useParams, useHistory } from 'react-router-dom'
import { makeStyles } from '@material-ui/core/styles'
import ListItemText from '@material-ui/core/ListItemText'
import ListItem from '@material-ui/core/ListItem'
import styles from '@assets/jss/pages/singleCourse'

const useStyles = makeStyles(styles)

const SectionItem = ({ lectureName, lectureSlug }) => {
  const c = useStyles()

  const { courseName } = useParams()
  const history = useHistory()

  const onClickHandle = slug => history.push(`/courses/${courseName}/${slug}`)

  return (
    <ListItem className={c.listItem} onClick={() => onClickHandle(lectureSlug)}>
      <ListItemText>{lectureName}</ListItemText>
    </ListItem>
  )
}

export default SectionItem
