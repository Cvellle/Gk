import React from 'react'

const AuthPage = () => (
    <>
        <div>Login</div>
    </>
)

export default AuthPage
