import React from 'react'

const ClassPage = () => (
    <>
        <div>Class</div>
    </>
)

export default ClassPage
