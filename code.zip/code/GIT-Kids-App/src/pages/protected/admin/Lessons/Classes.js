import React from 'react'

const ClassesPage = () => (
    <>
        <div>Classes</div>
    </>
)

export default ClassesPage
