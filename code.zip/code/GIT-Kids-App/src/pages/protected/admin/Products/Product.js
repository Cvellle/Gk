import React from 'react'

const ProductPage = () => (
    <>
        <div>Product Page</div>
    </>
)

export default ProductPage
