import React from 'react'

import Form from '@forms/AddProductForm/AddProductForm'

const AddProduct = () => (
    <>
        <Form />
    </>
)

export default AddProduct
