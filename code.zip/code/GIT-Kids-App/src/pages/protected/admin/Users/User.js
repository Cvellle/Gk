import React from 'react'
import EditProfileForm from '@forms/EditProfileForm'

const UserPage = () => (
    <>
        <div>
            <EditProfileForm />
        </div>
    </>
)

export default UserPage