import React from 'react'

const PayoutsPage = () => (
    <>
        <div>Payouts</div>
    </>
)

export default PayoutsPage
