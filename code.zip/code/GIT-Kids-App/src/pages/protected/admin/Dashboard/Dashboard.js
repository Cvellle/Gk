import React, { useEffect } from 'react'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Card from '@components/Card/Card'
import CardHeader from '@components/Card/CardHeader'
import CardIcon from '@components/Card/CardIcon'
import CardFooter from '@components/Card/CardFooter'
import Danger from '@components/Typography/Danger'
import Info from '@components/Typography/Info'
import Success from '@components/Typography/Success'
import WarningColor from '@components/Typography/Warning'

import Store from '@material-ui/icons/Store'
import Warning from '@material-ui/icons/Warning'
import DateRange from '@material-ui/icons/DateRange'
import Update from '@material-ui/icons/Update'
import LocalOffer from '@material-ui/icons/LocalOffer'
import PeopleIcon from '@material-ui/icons/People';

import withStyles from '@material-ui/core/styles/withStyles'

import style from '@assets/jss/pages/dashboardStyle'

// import { withApollo } from 'react-apollo'
import { useQuery, useMutation } from 'react-apollo-hooks';

import { USERS_QUERY } from '@apollo/server/queries'
import { POTENTIAL_USERS_QUERY } from '@apollo/server/queries';
import { TOOGLE_COLLAPSE } from '@apollo/client/mutations'

const DashboardPage = ({ classes }) => {
  const { refetch: refetchAll } = useQuery(USERS_QUERY);
  const { refetch: refetchPotential } = useQuery(POTENTIAL_USERS_QUERY);

  const toogleCollapse = useMutation(TOOGLE_COLLAPSE)

  useEffect(() => {
    toogleCollapse({ variables: { value: '' } })
    refetchAll()
    refetchPotential()
  }, [])


  // USE QUERIES
  const { data: allUsers } = useQuery(USERS_QUERY);
  const { data: potentialUsers } = useQuery(POTENTIAL_USERS_QUERY);

  // const { loading: allUsersLoading } = useQuery(USERS_QUERY);
  // const { loading: potentialUsersLoading } = useQuery(POTENTIAL_USERS_QUERY);

  // FILTER QUERIES
  let conditionUsers = allUsers && allUsers.users && allUsers.users.docs
  let conditionPotentialUsers = potentialUsers && potentialUsers.getPotentialUsers && potentialUsers.getPotentialUsers.docs
  
  const students = conditionUsers && allUsers.users.docs.filter((user) => {
    return ("STUDENT".indexOf(user.roles[0]) !== -1)
  })

  const parents = conditionUsers && allUsers.users.docs.filter((user) => {
    return ("PARENT".indexOf(user.roles[0]) !== -1)
  })

  const potentialParentsArray = conditionPotentialUsers && potentialUsers.getPotentialUsers.docs.filter((user) => {
    return ("PARENT".indexOf(user.roles[0]) !== -1)
  })

  // FILTERED LENGTH
  const numOfParents = parents && parents.length
  const numOfStudents = students && students.length
  const numOfPotentialParents = potentialParentsArray && potentialParentsArray.length

  // OLD CODE

  // let numberOfTotalUsers
  // if (!AllUsersLoading && !potentialUsersLoading) {
  //   numberOfTotalUsers = AllUsers.users.totalDocs
  //   numberOfPotUsers = potentialUsers.getPotentialUsers.totalDocs
  // }

  // let displayAllUsersNum
  // if (numberOfTotalUsers) {
  //   displayAllUsersNum = 
  //     <h3 className={classes.cardTitle} style={{ paddingTop: '1.8%' }}>
  //       {/* {numberOfTotalUsers} <small>{numberOfTotalUsers > 1 || numberOfTotalUsers === 0 ? 'KORISNIKA' : 'KORISNIK'}</small> */}
  //       {numOfUsers} <small>{numOfUsers > 1 || numOfUsers === 0 ? 'KORISNIKA' : 'KORISNIK'}</small>
  //   </h3>
  // } else {
  //   displayAllParentsNum = <div>Loading...</div>
  // }

  // DISPLAY STUDENTS
  let displayAllStudentsNum =
    <h3 className={classes.cardTitle} style={{ paddingTop: '1.8%' }}>
      {numOfStudents} <small>{numOfStudents > 1 || numOfStudents === 0 ? 'KORISNIKA' : 'KORISNIK'}</small>
    </h3>

  // DISPLAY PARENTS
  let displayAllParentsNum =
    <h3 className={classes.cardTitle} style={{ paddingTop: '1.8%' }}>
      {numOfParents} <small>{numOfParents > 1 || numOfParents === 0 ? 'KORISNIKA' : 'KORISNIK'}</small>
    </h3>

  // DISPLAY POTENTIAL PARENTS
  let displayAllPotParentsNum =
    <h3 className={classes.cardTitle} style={{ paddingTop: '1.8%' }}>
      {numOfPotentialParents}{' '}
      <small>{numOfPotentialParents > 1 || numOfPotentialParents === 0 ? 'KORISNIKA' : 'KORISNIK'}</small>
    </h3>


  return (

    <>
      <GridContainer>
        <GridItem xs={12} sm={6} md={6} lg={6}>
          <Card>
            <CardHeader color="success" stats icon>
              <CardIcon color="success">
                <PeopleIcon />
              </CardIcon>
              <p className={classes.cardCategory}></p>
              {displayAllPotParentsNum}
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <Success>
                  <PeopleIcon />
                </Success>
                <a href="/potential-users" style={{ color: 'rgba(0, 0, 0, 0.87' }}>
                  ZAINTERESOVANI RODITELJI
                </a>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={6} md={6} lg={6}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <PeopleIcon />
              </CardIcon>
              <p className={classes.cardCategory}></p>
              {displayAllParentsNum}
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <Info>
                  <PeopleIcon />
                </Info>
                <a href="/users/parents" style={{ color: 'rgba(0, 0, 0, 0.87' }}>
                  REGISTROVANI RODITELJI
                </a>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={6} md={6} lg={6}>
          <Card>
            <CardHeader color="warning" stats icon>
              <CardIcon color="warning">
                <PeopleIcon />
              </CardIcon>
              <p className={classes.cardCategory}></p>
              {displayAllStudentsNum}
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <WarningColor>
                  <PeopleIcon />
                </WarningColor>
                <a href="/users/students" style={{ color: 'rgba(0, 0, 0, 0.87' }}>
                  POLAZNICI
                </a>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
    </>
  )
}

export default withStyles(style)(DashboardPage)
