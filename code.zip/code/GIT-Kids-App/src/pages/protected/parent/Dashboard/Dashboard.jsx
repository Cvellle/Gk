import React, {useEffect} from 'react'
import { useQuery } from 'react-apollo-hooks'
import { makeStyles } from '@material-ui/core/styles'
import DateRange from '@material-ui/icons/DateRange'
import ReceiptIcon from '@material-ui/icons/Receipt'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Card from '@components/Card/Card'
import CardHeader from '@components/Card/CardHeader'
import CardIcon from '@components/Card/CardIcon'
import CardFooter from '@components/Card/CardFooter'
import Info from '@components/Typography/Info'
import styles from '@assets/jss/pages/dashboardStyle'
import { REMAINING_CHARGE } from '@apollo/server/queries'

const useStyles = makeStyles(styles)

const DashboardPage = () => {
  const classes = useStyles()

  const { data, refetch } = useQuery(REMAINING_CHARGE)

  useEffect(()=>{
    refetch()
  },[])


  return (
    <GridContainer>
      <GridItem xs={12} sm={6} md={6} lg={6}>
        <Card>
          <CardHeader color="info" stats icon>
            <CardIcon color="info">
              <ReceiptIcon />
            </CardIcon>
            <p className={classes.cardCategory}>Trenutno zaduženje</p>
            <h3 className={classes.cardTitle} style={{ paddingTop: '1.8%' }}>
              {data && data.me && data.me.remainingCharge && data.me.remainingCharge} <small>DIN</small>
            </h3>
          </CardHeader>
          <CardFooter stats>
            <div className={classes.stats}>
              <Info>
                <DateRange />
              </Info>
              <a href="/" style={{ color: 'rgba(0, 0, 0, 0.87' }}>
                Rok za placanje {'datum: 12.12.2012'}
              </a>
            </div>
          </CardFooter>
        </Card>
      </GridItem>
    </GridContainer>
  )
}

export default DashboardPage
