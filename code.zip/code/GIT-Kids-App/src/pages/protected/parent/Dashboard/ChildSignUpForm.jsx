import React, { useState } from 'react'
import { withStyles } from '@material-ui/core'
import GridContainer from '@components/Grid/GridContainer'
import GridItem from '@components/Grid/GridItem'
import Button from '@components/CustomButtons/Button'
import { FormikTextInput, FormikSelectInput, FormikDatePicker } from '@inputs'
import Card from '@components/Card/Card'
import { Formik, Field, ErrorMessage } from 'formik'
import { ADD_CHILD } from '@apollo/server/mutations'
import SweetAlert from 'react-bootstrap-sweetalert'


import useReactRouter from 'use-react-router'

import style from '@assets/jss/forms/addUserForm'
import * as yup from 'yup'
import { makeStyles } from '@material-ui/core/styles'

// Apollo
import { useQuery } from 'react-apollo-hooks'
import { useMutation } from 'react-apollo-hooks'
import { POTENTIAL_USERS_QUERY } from '@apollo/server/queries'
import { USERS_QUERY } from '@apollo/server/queries'

const initialValues = {
  firstName: '',
  lastName: '',
  email: '',
  city: '',
  address: '',
  paymentDynamics: '',
  paymentMethod: '',
  birthDate: '',
}

const validationSchema = yup.object().shape({
  firstName: yup.string().required('Ime deteta je obavezno.'),
  lastName: yup.string().required('Prezime deteta je obavezno.'),
  email: yup
    .string()
    .email('Email nije validan.')
    .required('Email deteta je obavezan.'),
  city: yup.string().required('Grad korisnika je obavezan.'),
  address: yup.string().required('Adresa staratelja je obavezna.'),
  paymentDynamics: yup.string().required('Polje obavezno.'),
  paymentMethod: yup.string().required('Polje obavezno.'),
  birthDate: yup.string().required('Datum rođenja korisnika je obavezan.'),
})

const useStyles = makeStyles({
  root: {
    '& .MuiFormHelperText-root': {
      display: 'none',
    },
  },
})

const ChildSignUpForm = ({ classes: c }) => {
  const [hasErrors, setErrorState] = useState({ isTrue: false, message: null })
  const [alert, setAlert] = useState(null);
  const classesField = useStyles()
  // const classesSelectField = selectMenuStyle()

  const { history } = useReactRouter()
  const addChildMutation = useMutation(ADD_CHILD)


  //Success
  const hideAlert = () => {
    setAlert(null);
    history.push('/')
  };
  const successAlert = () => {
    setAlert(
      <SweetAlert
        title = ''
        success
        style={{ display: "block", marginTop: "-100px" }}

        onConfirm={() => hideAlert()}
        onCancel={() => hideAlert()}
        btnSize="lg"
        confirmBtnStyle={{color:'white', padding:'3% 7%',border:"none",backgroundColor:'#5FB85C',borderRadius:'5px',cursor:'pointer'}}


      >
      <h4>Registracija uspešna!</h4>
      </SweetAlert>
    );
  };


  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={async (values, actions) => {
        try {
          console.log('values',values)
          const response = await addChildMutation({
            variables: values,
            //role,
          })
          if(response){
            console.log(successAlert,'aler')
          successAlert()()
         }

          console.log(response)
          actions.setSubmitting(false)
          setErrorState({ isTrue: false, message: null })



          console.log('kreiranje uspesno')
          history.push(`/`)
        } catch ({ graphQLErrors }) {
          graphQLErrors?setErrorState({ isTrue: true, message: graphQLErrors.toString() }):console.log('')
          actions.setSubmitting(false)
        }
      }}
      render={({ handleSubmit, isSubmitting }) => (

        <Card className={c.card}>
          {alert?alert:null}
          <form onSubmit={handleSubmit} noValidate>
            <div className={c.formHeader}>
              <h3 className={c.title}>{`Upis Deteta`}</h3>
            </div>
            <div className={c.content}>
              <GridContainer justify="flex-start">
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="firstName"
                    label="Ime deteta"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'firstName'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="lastName"
                    label="Prezime deteta"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'lastName'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="email"
                    label="Email deteta"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'email'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                {/* <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="nativeFirstName"
                                        label="Native First Name"
                                        component={FormikTextInput}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="nativeLastName"
                                        label="Native Last Name"
                                        component={FormikTextInput}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="country"
                                        label="Country"
                                        component={FormikTextInput}
                                    />
                                </GridItem>
                                <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        name="region"
                                        label="Region"
                                        component={FormikTextInput}
                                    />
                                </GridItem> */}
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="address"
                    label="Adresa staratelja"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'address'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="city"
                    label="Grad"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'city'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                {
                  <GridItem xs={12} sm={6}>
                    <Field
                      required
                      options={[
                        {
                          label: 'Uplatnica',
                          value: 'PAYMENT_FORM',
                        },
                      ]}
                      name="paymentMethod"
                      label="Način plaćanja"
                      component={FormikSelectInput}
                      // classes={{
                      //     root: classesField.root,
                      //     // class name, e.g. `classes-nesting-root-x`

                      //   }}
                      // classes={{
                      //     root: classesSelectField.root,
                      //     // class name, e.g. `classes-nesting-root-x`

                      //   }}
                    />
                    <div style={{ height: '14px' }}>
                      <ErrorMessage name={'paymentMethod'}>
                        {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                      </ErrorMessage>
                    </div>
                  </GridItem>
                }

                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    options={[
                      {
                        label: 'Mesečno',
                        value: 'MONTHLY',
                      },

                      {
                        label: 'Na svakih od 6 meseci',
                        value: 'SIX_MONTHS',
                      },
                      {
                        label: 'Na svakih 12 meseci',
                        value: 'TWELVE_MONTHS',
                      },
                    ]}
                    name="paymentDynamics"
                    label="Dinamika plaćanja"
                    component={FormikSelectInput}
                    // classes={{
                    //     root: classesField.root,
                    //     // class name, e.g. `classes-nesting-root-x`

                    //   }}
                    // classes={{
                    //     root: classesSelectField.root,
                    //     // class name, e.g. `classes-nesting-root-x`

                    //   }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'paymentDynamics'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>

                {/* <GridItem xs={12} sm={6}>
                                    <Field
                                        required
                                        options={TIMEZONES.map(zone => {
                                            return {
                                                label: stringifyZone(
                                                    zone,
                                                    'GMT',
                                                ),
                                                value: zone.name,
                                            }
                                        })}
                                        name="timeZone"
                                        label="Time Zone"
                                        component={FormikSelectInput}
                                    />
                                </GridItem> */}
                {/*         <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="phone"
                    label="Telefon"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'phone'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="postalCode"
                    label="Poštanski broj"
                    component={FormikTextInput}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'postalCode'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                                </GridItem> */}
                <GridItem xs={12} sm={6}>
                  <Field
                    required
                    name="birthDate"
                    label="Datum rođenja deteta"
                    component={FormikDatePicker}
                    classes={{
                      root: classesField.root,
                      // class name, e.g. `classes-nesting-root-x`
                    }}
                  />
                  <div style={{ height: '14px' }}>
                    <ErrorMessage name={'birthDate'}>
                      {msg => <div style={{ color: 'red', fontSize: '14px' }}>{msg}</div>}
                    </ErrorMessage>
                  </div>
                </GridItem>
              </GridContainer>
            </div>
            <div className={c.footer}>
              <GridContainer justify="flex-end">
                <Button className={c.button} color="primary" type="submit" disabled={isSubmitting}>
                  Upiši Dete
                </Button>
              </GridContainer>
            </div>
            {
              <p style={{ color: 'red', visibility: 'visible', height: '15px', textAlign: 'center' }}>
                {hasErrors.isTrue ? hasErrors.message : ' '}
              </p>
            }
          </form>
        </Card>
      )}

    />
  )
}

export default withStyles(style)(ChildSignUpForm)
