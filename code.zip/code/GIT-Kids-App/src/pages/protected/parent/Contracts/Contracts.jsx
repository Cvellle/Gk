import React from 'react'
import useReactRouter from 'use-react-router'
import { withApollo } from 'react-apollo'
import { FETCH_ALL_KIDS } from '@apollo/server/queries'
// import { makeStyles } from '@material-ui/core/styles'
import CustomTable from '@components/CustomTable'
// import styles from '@assets/jss/pages/usersPage'

// const useStyles = makeStyles(styles)

const columns = [
  {
    title: 'Ime',
    field: 'firstName',
  },
  { title: 'Prezime', field: 'lastName' },
  { title: 'Ugovor potpisan', field: 'signingDate' },
  { title: 'Ugovor ističe', field: 'expirationDate' },
  { title: 'Dinamika plaćanja', field: 'paymentDynamics'},
  { title: 'Broj ugovora', field: 'contractNumber'}
]

const ContractsPage = ({ client }) => {
  //   const classes = useStyles()
  const { history } = useReactRouter()

  // const onAdd = () => history.push(`/register-child`)
  // const onDetails = (_, row) => history.push(`/users/${row._id}`)

  const getData = async e => {
    const { query } = client
    let queryOptions = {
      query: FETCH_ALL_KIDS,
      fetchPolicy: 'network-only',
      variables: {
        pagination: {
          page: e.page + 1,
          limit: e.pageSize,
        },
        search: e.search,
      },
    }

    if (e.orderBy) {
      queryOptions.variables = {
        ...queryOptions.variables,
        sort: {
          field: e.orderBy.field,
          order: e.orderDirection === 'asc' ? 1 : -1,
        },
      }
    }

    const response = await query(queryOptions)
    const { users } = response.data

    const data = users.docs[0].children.map(child => {
      return {...child.childId, paymentDynamics: child.paymentDynamics}
    })




    return {
      data: data,
      page: e.page,
      totalCount: users.docs.length,
    }
  }


  return (
    <CustomTable
      title={'Ugovori'}
      columns={columns}
      data={getData}
      // onRowClick={onDetails}
      // onAdd={onAdd}
    />
  )
}

export default withApollo(ContractsPage)
