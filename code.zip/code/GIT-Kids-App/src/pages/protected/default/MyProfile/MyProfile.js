import React from 'react'
import EditProfileForm from '@forms/EditProfileForm'

const MyProfile = () => (
    <>
        <div>
            <EditProfileForm />
        </div>
    </>
)

export default MyProfile
