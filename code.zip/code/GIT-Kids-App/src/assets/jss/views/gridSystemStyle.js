import { grayColor } from '../main'

const gridSystemStyle = {
  title: {
    color: grayColor[2],
    textDecoration: 'none',
  },
}

export default gridSystemStyle
