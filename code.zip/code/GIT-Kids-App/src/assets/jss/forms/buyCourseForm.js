import { transition } from '../main'

const buyCourseFormStyle = theme => ({
	buyingConatainer: {
		...transition
	},
	button: {
		marginLeft: 5,
		...transition
	}
})

export default buyCourseFormStyle
