import admin from './admin'
import manager from './manager'
import amm from './amm'
import referral from './referral'
import sales from './sales'
import support from './support'
import teacher from './teacher'
import student from './student'
import parent from './parent'

const LINKS = {
  admin,
  manager,
  amm,
  referral,
  sales,
  support,
  teacher,
  student,
  parent,
}

export default LINKS
