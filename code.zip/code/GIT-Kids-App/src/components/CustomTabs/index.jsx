import CustomTabs from './CustomTabs'

export default CustomTabs
