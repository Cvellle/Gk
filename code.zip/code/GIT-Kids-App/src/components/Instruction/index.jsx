import Instructions from './Instruction'

export default Instructions
