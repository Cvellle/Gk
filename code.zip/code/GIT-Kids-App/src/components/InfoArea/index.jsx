import InfoArea from './InfoArea'

export default InfoArea
