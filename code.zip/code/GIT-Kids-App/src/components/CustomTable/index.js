import CustomTable from './CustomTable'

export default CustomTable
