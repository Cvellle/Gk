import Header from './Header'
import HeaderLinks from './HeaderLinks'
import PagesHeader from './PagesHeader'

export default { Header, HeaderLinks, PagesHeader }
