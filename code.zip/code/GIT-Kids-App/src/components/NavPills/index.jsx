import NavPills from './NavPills'

export default NavPills
