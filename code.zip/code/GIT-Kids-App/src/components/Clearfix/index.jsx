import Clearfix from './Clearfix'

export default Clearfix
