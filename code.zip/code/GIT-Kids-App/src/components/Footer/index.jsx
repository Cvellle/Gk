import Footer from './Footer'

export default Footer
