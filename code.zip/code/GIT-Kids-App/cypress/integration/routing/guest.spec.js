const authorizedRoutes = ['/login']

const unauthorizedRoutes = [
    '/meetings/all',
    '/meetings/my',
    '/courses/active',
    '/courses/completed',
    '/users/admins',
    '/users/admins/add',
    '/users/managers',
    '/users/managers/add',
    '/users/amm',
    '/users/amm/add',
    '/users/referrals',
    '/users/referrals/add',
    '/users/sales',
    '/users/sales/add',
    '/users/teachers',
    '/users/teachers/add',
    '/users/students',
    '/users/students/add',
    '/users/support',
    '/users/support/add',
    '/classes',
    '/shop',
    '/blog',
    '/payouts',
    '/tickets',
    '/shop/educational-program',
    '/edit/educational-program',
]

const baseUrl = 'http://localhost:3000'

context('Routing as a Guest', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.clearLocalStorage()
    })

    it('Go to project root (dashboard) - "/"', () => {
        cy.visit('/')
        cy.url().should('eq', `${baseUrl}/login`)

        authorizedRoutes.forEach(route => {
            cy.visit(route)
            cy.url().should('eq', `${baseUrl}${route}`)
        })

        unauthorizedRoutes.forEach(route => {
            cy.visit(route)
            cy.url().should('eq', `${baseUrl}/login`)
        })
    })
})
