const authorizedRoutes = [
    '/',
    '/users/students',
    '/users/students/add',
    '/tickets',
    '/login',
]

const unauthorizedRoutes = [
    '/classes',
    '/shop',
    '/meetings/all',
    '/meetings/my',
    '/users/admins',
    '/users/admins/add',
    '/users/managers',
    '/users/managers/add',
    '/users/amm',
    '/users/amm/add',
    '/users/referrals',
    '/users/referrals/add',
    '/users/sales',
    '/users/sales/add',
    '/users/teachers',
    '/users/teachers/add',
    '/courses/active',
    '/courses/completed',
    '/users/support',
    '/users/support/add',
    '/blog',
    '/payouts',
    '/shop/educational-program',
    '/edit/educational-program',
]

const baseUrl = 'http://localhost:3000'

context('Routing as a Referral', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.clearLocalStorage()
    })

    it('Go to project root (dashboard) - "/"', () => {
        // Go to root and get
        cy.visit('/')
        cy.url().should('includes', 'login')
        cy.get('button[data-testid="referral-login"]').click()
        cy.url().should('eq', 'http://localhost:3000/')

        authorizedRoutes.forEach(route => {
            cy.visit(route)
            cy.url().should('eq', `${baseUrl}${route}`)
        })

        unauthorizedRoutes.forEach(route => {
            cy.visit(route)
            cy.url().should('eq', `${baseUrl}/`)
        })
    })
})
